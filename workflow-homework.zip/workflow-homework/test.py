import dashscope
from dashscope import Generation

dashscope.api_key = "sk-ws-H.PLXXRPE.UzPf.MEUCIH76L6d7KrV0pHBjBkRpRuiGo3kn1cPSi8Mz3dwYZeQ_AiEAwfp9fc_IAqphCwfGtI_b4Lvq5H0MFnHYkEMsNE2CAFw"

response = Generation.call(
    model="qwen-plus",
    messages=[{"role": "user", "content": "说一句测试成功"}],
    result_format='message'
)

print("状态码：", response.status_code)
if response.status_code == 200:
    print("返回内容：", response.output.choices[0].message.content)
else:
    print("错误详情：", response)
