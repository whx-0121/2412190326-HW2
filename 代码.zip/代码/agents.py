"""
Agent模块：定义所有参与工作流的智能体
每个Agent只负责一项任务，通过状态上下文传递数据
"""
import dashscope
from dashscope import Generation
from config import DASHSCOPE_API_KEY, MODEL_NAME

dashscope.api_key = DASHSCOPE_API_KEY


class BaseAgent:
    """
    Agent基类：定义统一的接口规范
    所有具体的Agent都继承这个类，必须实现run方法
    为什么要基类：保证所有Agent格式统一，工作流可以统一调度
    """
    def __init__(self, name):
        self.name = name  

    def run(self, state):
        """
        核心执行方法，接收状态，处理后返回新状态
        :param state: 工作流状态上下文，所有数据都存在这里
        """
        raise NotImplementedError("子类必须实现run方法")


class CodingAgent(BaseAgent):
    """
    编码Agent：第一个节点，根据用户需求生成初始代码
    对应项目1复用的代码生成能力
    """
    def __init__(self):
        super().__init__("编码Agent")

    def run(self, state):
     
        requirement = state.get("requirement", "")
        
       
        messages = [{"role": "user", "content": f"""
        请根据以下需求生成规范的Python代码：
        需求：{requirement}
        要求：
        1. 代码符合PEP8编码规范
        2. 添加清晰的功能注释
        3. 变量命名有实际意义
        4. 只输出代码和注释，不要多余解释文字
        """}]

        response = Generation.call(model=MODEL_NAME, messages=messages, result_format='message')
    
        if response.status_code == 200:
            state["code"] = response.output.choices[0].message.content
        else:
            state["code"] = f"代码生成失败，错误码：{response.status_code}"
        
        return state


class ReviewAgent(BaseAgent):
    """
    审查Agent：第二个节点，对代码进行质量审查
    对应项目1复用的代码审查能力
    """
    def __init__(self):
        super().__init__("审查Agent")

    def run(self, state):
     
        code = state.get("code", "")
        
        messages = [{"role": "user", "content": f"""
        请对以下 Python 代码进行质量审查：
        ```python
        {code}
        ```
        从以下几个方面分析：

        1. 潜在的 Bug 和逻辑问题
        2. 代码规范问题
        3. 性能优化建议
        4. 可维护性改进建议
        分点清晰说明。
        """}]

        response = Generation.call(model=MODEL_NAME, messages=messages, result_format='message')


   

        if response.status_code == 200:
            state["review_result"] = response.output.choices[0].message.content
        else:
            state["review_result"] = f"代码审查失败，错误码：{response.status_code}"
        return state

class FixAgent(BaseAgent):
    """
    修复 Agent：第三个节点，根据审查意见修复代码
    """
    def __init__(self):
        super().__init__("修复 Agent")

    def run(self, state):
  
        code = state.get("code", "")
        review_result = state.get("review_result", "")

        messages = [{"role": "user", "content": f"""
        请根据审查意见修复下面的代码：
        原始代码：
        ```python
        {code}
        ```
        审查意见：
        {review_result}

        要求：
        1. 针对审查意见逐一修复问题
        2. 保留代码的核心功能
        3. 输出修复后的完整代码，只输出代码，不要多余解释
        """}]
        response = Generation.call(model=MODEL_NAME, messages=messages, result_format='message')


        if response.status_code == 200:
            state["final_code"] = response.output.choices[0].message.content
        else:
            state["final_code"] = f"代码修复失败，错误码：{response.status_code}"
        return state