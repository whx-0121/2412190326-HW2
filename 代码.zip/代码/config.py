"""
配置文件：统一管理项目所有参数
"""
DASHSCOPE_API_KEY = "sk-ws-H.PLXXRPE.UzPf.MEUCIH76L6d7KrV0pHBjBkRpRuiGo3kn1cPSi8Mz3dwYZeQ_AiEAwfp9fc_IAqphCwfGtI_b4Lvq5H0MFnHYkEMsNE2CAFw"
MODEL_NAME = "qwen-plus"

