"""
主程序入口：组装并运行代码审查修复工作流
"""
from agents import CodingAgent, ReviewAgent, FixAgent
from workflow import SimpleWorkflow


def main():

    workflow_agents = [
        CodingAgent(),
        ReviewAgent(),
        FixAgent()
    ]
    code_review_workflow = SimpleWorkflow(workflow_agents)
    init_data = {
        "requirement": "写一个函数，实现冒泡排序算法，支持对整数列表排序"
    }
    final_state = code_review_workflow.run(init_data)
    print("\n" + "=" * 60)
    print("最终结果汇总")
    print("=" * 60)
    
    print("\n1️⃣ 生成的初始代码：")
    print("-" * 40)
    print(final_state.get("code"))
    
    print("\n2️⃣ 代码审查意见：")
    print("-" * 40)
    print(final_state.get("review_result"))
    
    print("\n3️⃣ 修复后的最终代码：")
    print("-" * 40)
    print(final_state.get("final_code"))


if __name__ == "__main__":
    main()
