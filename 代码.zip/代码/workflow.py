"""
工作流模块：实现状态管理和流程编排
是整个Workflow的核心调度器
"""

class WorkflowState:
    """
    工作流状态上下文
    作用：在所有Agent之间共享数据，实现Agent间的消息传递
    所有Agent都从这里读数据、写完数据再放回来，不用直接互相调用
    """
    def __init__(self, init_data=None):
       
        self.data = init_data if init_data else {}

    def get(self, key, default=None):
        """读取状态里的数据"""
        return self.data.get(key, default)

    def __setitem__(self, key, value):
        """往状态里写数据"""
        self.data[key] = value

    def to_dict(self):
        """返回全部状态的副本"""
        return self.data.copy()


class SimpleWorkflow:
    """
    简单工作流编排器
    作用：按顺序执行所有Agent节点，管理整个流程的生命周期
    """
    def __init__(self, agents):
       
        self.agents = agents

    def run(self, init_state):
        """
        启动整个工作流
        :param init_state: 初始输入数据
        :return: 执行完所有节点后的最终状态
        """
      
        state = WorkflowState(init_state)
        print(f"▶️ 工作流启动，初始需求：{state.get('requirement')}")

      
        for agent in self.agents:
            print(f"\n-------- 正在执行：{agent.name} --------")
            state = agent.run(state)
            print(f"✅ {agent.name} 执行完成")

        print("工作流全部执行完毕!!")
        return state
